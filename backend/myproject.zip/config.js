const dbString = "mongodb://127.0.0.1/vaja3";
const dbPw = "";


export {dbString, dbPw};
